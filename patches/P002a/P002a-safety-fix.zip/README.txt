P002a SAFETY FIX — KEEP YOUR CURRENT SAVE

The warehouse's old east-facing stairs enter an unused multiplayer Colosseum.
P002a blocks that stair. Use the damaged sign after winning Mister R to enter
the Office service room. The new chapter ends there; the stadium is not a story
battle. The inherited chair route can start invalid/stalled link interactions.

1. Back up your CURRENT save and ROM with FlashGBX. Keep the originals.
2. Open Make-Safety-Fix.html in Chrome, Edge or Firefox.
3. Select that fresh16 or32 MiB ROM dump and current128 KiB .sav backup.
4. Click Create, then Download P002a-keep-progress.gba.
5. Use your already-working FlashGBX procedure, retaining/restoring that CURRENT
   save as your cartridge requires. Do not substitute the pre-puzzle test save.

This changes one map collision word and embeds your chosen current save in a
copy; it preserves16/32 MiB size and upper-bank bytes. No driver, item, battle,
flag, variable or save format changes. Both save slots are checked with native
LC checksum lengths. The page stops if saved in the broken stadium or if save
data is invalid; send that backup for recovery rather than overwriting it.
The fix does not recover unsaved progress. Everything runs offline; no uploads.
The original ROM/save files stay unchanged. No new hardware compatibility claim.

The BPS files here are an alternative ONLY for the exact standard P002/P002a
builds. They do not embed your latest progress. Use the HTML tool for a cart
dump or a ROM with a different embedded save.

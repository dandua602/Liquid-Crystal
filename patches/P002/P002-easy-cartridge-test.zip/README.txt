LIQUID CRYSTAL — MAKE THE WAREHOUSE CARTRIDGE TEST ROM

1. Extract this ZIP.
2. Open Make-Test-ROM.html in Chrome, Edge or Firefox.
3. Choose the exact original POKEMON Liquid Crystal.gba you uploaded.
4. Click Create and download test ROM. Find P002-warehouse-test.gba in Downloads.
5. In FlashGBX use Write ROM and your existing correct cart profile, then verify.
6. Boot the console and Continue. You start beside the warehouse rock puzzle.

No Python or separate patcher installation needed. Everything runs offline on
your computer. No ROM or save file is uploaded. Original files are unchanged.

The output includes a separate artificial pre-puzzle save with six native-stat
level100 Pokemon, Iron Tail/Surf and the retained Old Key/door unlock. It is not
your personal progress. Face right/A for the rock; decline the battle to test
Save and power-off/reload. Then face left/A at the sign to retry the battle.
The test save is embedded: do not restore a separate save for this initial test.

Use the same compatible cartridge family/profile as the uploaded conversion.
Physical-console compatibility and chip timing still need your test. Full guide:
https://github.com/dandua602/Liquid-Crystal/blob/main/HARDWARE_TEST.md

The included P002-warehouse-test.bps is an alternative for a BPS patcher. Apply
it DIRECTLY to your original Liquid Crystal upload, not P001/P002 or FireRed.
The BPS and browser tool produce the exact same previously tested 16 MiB ROM.
This ZIP contains patches, the offline tool and instructions; no ROM/save files.

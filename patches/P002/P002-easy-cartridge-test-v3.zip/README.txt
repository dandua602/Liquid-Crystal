LIQUID CRYSTAL — MAKE THE WAREHOUSE CARTRIDGE TEST ROM

1. Extract this ZIP.
2. Open Make-Test-ROM.html in Chrome, Edge or Firefox.
3. Choose the original upload, exact P001 or exact P002 ROM.
   A later cart dump is supported only when its game/driver bytes match one of
   those and you also select your original 5-badge .sav backup. The page checks
   that backup before normalizing the embedded save in a memory-only copy.
4. Click Create and download test ROM. Find P002-warehouse-test.gba in Downloads.
5. Keep these files for diagnosis. The user's physical saving test failed.
6. Before another write, use FlashGBX Backup ROM at the detected 32 MiB and
   preserve the failed cart's complete readback for comparison.

If automatic downloading does not start, click the visible Download ROM link.
If rejected, open File details and copy the size/hash for troubleshooting.
V3 also offers Download matching P002-warehouse-test.sav (128 KiB raw payload,
without a FlashGBX metadata trailer). It is identical to the embedded test save.
You can select an already-generated P002-warehouse-test.gba to obtain this save.
The real-cart test reported a corruption warning and stuck Saving. A separate
save download is for diagnosis, not a confirmed fix. Cart/profile and a full ROM
readback after the failed attempt are needed before recommending a save restore.

No Python or separate patcher installation needed. Everything runs offline on
your computer. No ROM or save file is uploaded. Original files are unchanged.

The output includes a separate artificial pre-puzzle save with six native-stat
level100 Pokemon, Iron Tail/Surf and the retained Old Key/door unlock. It is not
your personal progress. Face right/A for the rock; decline the battle to test
Save and power-off/reload. Then face left/A at the sign to retry the battle.
The test save is embedded: do not restore a separate save for this initial test.

Use the same compatible cartridge family/profile as the uploaded conversion.
Physical-console compatibility and chip timing still need your test. Full guide:
https://github.com/dandua602/Liquid-Crystal/blob/main/HARDWARE_TEST.md

The included P002-warehouse-test.bps is an alternative for a BPS patcher. Apply
it DIRECTLY to your original Liquid Crystal upload, not P001/P002 or FireRed.
The BPS and browser tool produce the exact same previously tested 16 MiB ROM.
This ZIP contains patches, the offline tool and instructions; no ROM/save files.
